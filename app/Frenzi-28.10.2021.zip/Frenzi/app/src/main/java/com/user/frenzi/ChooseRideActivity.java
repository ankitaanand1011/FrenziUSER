package com.user.frenzi;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioGroup;

import com.example.frenzi.R;
import com.user.frenzi.Responce.ResponceFetchRecentAddressList;
import com.user.frenzi.adapter.AdapterRecentAddressList;

public class ChooseRideActivity extends AppCompatActivity {


    String Status = null;
    ImageView btn_back;
    Button btn_book_now;
    AlertDialog alertDialog, alertDialog1;
    RadioGroup radio_group;
    RecyclerView recycler_view_car_list;

    private static final String TAG = "Choosecar";

    @Override
    protected void onPause() {
        super.onPause();
        overridePendingTransition(R.anim.trans_left_in, R.anim.trans_left_out);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose_ride);
        btn_back = findViewById(R.id.btn_back);
        btn_book_now = findViewById(R.id.btn_book_now);
        recycler_view_car_list=findViewById(R.id.recycler_view_car_list);
        btn_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
        btn_book_now.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                popUpPrefarence();
            }
        });


//        if (Build.VERSION.SDK_INT >= 21) {
//            Window window = getWindow();
//            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
//            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        //           window.setStatusBarColor(getResources().getColor(R.color.MidnightBlue));
        //       }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {

            getWindow().setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
        }

        adapterRecentAddressList = new AdapterRecentAddressList(getApplicationContext(), RecentAddresses, new AdapterRecentAddressList.OnItemClickListener() {
            @Override
            public void onItemClick(ResponceFetchRecentAddressList.Response item) {

            }
        });


        RecyclerView.LayoutManager mmLayoutManager = new LinearLayoutManager(this);
        recent_address_recycler.setLayoutManager(mmLayoutManager);
        recent_address_recycler.setItemAnimator(new DefaultItemAnimator());
        recent_address_recycler.setAdapter(adapterRecentAddressList);

        FetchRecentAddress();


    }

    private void popUppayment() {

        // get prompts.xml view
        LayoutInflater li = LayoutInflater.from(this);
        View promptsView = li.inflate(R.layout.popup_payment_choose, null);

        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this
        );

        Button btn_pay_now = promptsView.findViewById(R.id.btn_pay_now);
        Button btn_pay_later = promptsView.findViewById(R.id.btn_pay_later);

        // set prompts.xml to alertdialog builder
        alertDialogBuilder.setView(promptsView);

        btn_pay_now.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                Intent in=new Intent(ChooseRideActivity.this,DriverNearbyActivity.class);
//                startActivity(in);
//                finish();
  //              Intent in = new Intent(ChooseRideActivity.this, StripeAccountActivity.class);
//                startActivity(in);
//                finish();

                if (Status.equalsIgnoreCase("1")) {
                    Intent in = new Intent(ChooseRideActivity.this, PaymenyMethodActivity.class);
                    startActivity(in);
                    finish();

                } else if (Status.equalsIgnoreCase("0")) {
                    Intent in = new Intent(ChooseRideActivity.this, StripeAccountActivity.class);
                    startActivity(in);
                    finish();
                }
            }
        });


        btn_pay_later.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (Status.equalsIgnoreCase("1")) {
                    Intent in = new Intent(ChooseRideActivity.this, DriverChoiceActivity.class);
                    startActivity(in);
                    finish();

                } else if (Status.equalsIgnoreCase("0")) {
                    Intent in = new Intent(ChooseRideActivity.this, DriverNearbyActivity.class);
                    startActivity(in);
                    finish();
                }


            }
        });


        // create alert dialog
        alertDialog = alertDialogBuilder.create();
        alertDialog.setCancelable(false);
        // show it
        alertDialog.show();
    }

    private void popUpPrefarence() {

        // get prompts.xml view
        LayoutInflater li = LayoutInflater.from(this);
        View promptsView = li.inflate(R.layout.popup_driver_choice, null);

        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this
        );

        Button btn_preferr = promptsView.findViewById(R.id.btn_preferr);
        Button btn_next = promptsView.findViewById(R.id.btn_next);


//        TextView txt_cancel = (TextView) promptsView.findViewById(R.id.txt_cancel);


        // set prompts.xml to alertdialog builder
        alertDialogBuilder.setView(promptsView);



        btn_preferr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                Intent in=new Intent(ChooseRideActivity.this,DriverNearbyActivity.class);
//                startActivity(in);
//                finish();
                alertDialog1.dismiss();
                popUppayment();
                Status = "1";

              //Add data to local database

                SharedPreferences sp = getSharedPreferences(Constant.USER_PREF, Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = sp.edit();
                editor.putString(Constant.DRIVER_PREF, "1");
                editor.apply();

            }
        });


        btn_next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                alertDialog1.dismiss();
                Status = "0";
                popUppayment();
                //Add data to local database

                SharedPreferences sp = getSharedPreferences(Constant.USER_PREF, Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = sp.edit();
                editor.putString(Constant.DRIVER_PREF, "0");
                editor.apply();
            }
        });


        // create alert dialog
        alertDialog1 = alertDialogBuilder.create();
        alertDialog1.setCancelable(false);
        // show it
        alertDialog1.show();
    }

}