package com.user.frenzi;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.frenzi.R;

public class ProfileDetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_detail);
    }
}