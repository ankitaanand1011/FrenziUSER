package com.user.frenzi;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import com.example.frenzi.R;

public class DriverDetailsAfterBpookingActivity extends AppCompatActivity {

    Button button_next;
    ImageView btn_back;
    Button btn_cancellation;
    AlertDialog alertDialog;

    @Override
    protected void onPause() {
        super.onPause();
        overridePendingTransition(R.anim.trans_left_in, R.anim.trans_left_out);
    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_driver_details_after_bpooking);


        btn_back=findViewById(R.id.btn_back);
        btn_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
        btn_cancellation=findViewById(R.id.btn_cancellation);
        btn_cancellation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                popUp();
            }
        });


        button_next=findViewById(R.id.button_next);
        button_next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent cancel=new Intent(DriverDetailsAfterBpookingActivity.this,EmergencyTwoActivity.class);
                startActivity(cancel);
            }
        });


    }

    private void popUp() {

        // get prompts.xml view
        LayoutInflater li = LayoutInflater.from(this);
        View promptsView = li.inflate(R.layout.popup_cancel, null);

        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this
        );

        Button yes =promptsView.findViewById(R.id.yes);
        Button no =promptsView.findViewById(R.id.no);


//        TextView txt_cancel = (TextView) promptsView.findViewById(R.id.txt_cancel);


        // set prompts.xml to alertdialog builder
        alertDialogBuilder.setView(promptsView);
        yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent cancel=new Intent(DriverDetailsAfterBpookingActivity.this,MapScreen.class);
                startActivity(cancel);            }
        });
        no.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               alertDialog.dismiss();
            }
        });

//        radio_group.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
//            @Override
//            public void onCheckedChanged(RadioGroup radioGroup, int i) {
//                View radioButton = radio_group.findViewById(i);
//                int index = radio_group.indexOfChild(radioButton);
//
//                // Add logic here
//
//                switch (index) {
//                    case 0: // first button
//
////                        Toast.makeText(getApplicationContext(), "Selected button number " +index ,Toast.LENGTH_LONG).show();
//                        break;
//                    case 1: // secondbutton
//
////                        Toast.makeText(getApplicationContext(), "Selected button numbers "+index,Toast.LENGTH_LONG).show();
//                        break;
//                }
//            }
//        });





        btn_cancellation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {



//                Intent intent=new Intent(DestinationReachedActivity.this,RatingDriverRideActivity.class);
//                startActivity(intent);
//                finish();

            }
        });


        // create alert dialog
        alertDialog = alertDialogBuilder.create();
        alertDialog.setCancelable(false);
        // show it
        alertDialog.show();
    }
}