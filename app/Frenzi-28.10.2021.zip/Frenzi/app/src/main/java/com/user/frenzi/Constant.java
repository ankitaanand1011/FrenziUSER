package com.user.frenzi;

public class Constant {
    public static final String USER_PREF = "USER_PREF";
    public static final String DRIVER_PREF = "DRIVER_PREF";
    public static final String USER_NAME = "USER_NAME";
    public static final String USER_ID = "USER_ID";
    public static final String USER_MAIL = "USER_MAIL";
    public static final String USER_ADDRESS = "USER_ADDRESS";
}
