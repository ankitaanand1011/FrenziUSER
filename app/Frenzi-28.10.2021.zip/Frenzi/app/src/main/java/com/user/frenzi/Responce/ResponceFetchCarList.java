package com.user.frenzi.Responce;

public class ResponceFetchCarList {
}
